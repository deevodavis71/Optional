package com.airbus.smartdeploy.ordermanagement.web.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.airbus.smartdeploy.common.exception.InvalidRequestException;
import com.airbus.smartdeploy.common.security.TokenAuthenticationService;
import com.airbus.smartdeploy.common.utils.StringUtils;
import com.airbus.smartdeploy.common.versioning.VersionUtils;
import com.airbus.smartdeploy.ordermanagement.dto.CapabilityDto;
import com.airbus.smartdeploy.ordermanagement.dto.UpdateCapabilityDto;
import com.airbus.smartdeploy.ordermanagement.entity.Capability;
import com.airbus.smartdeploy.ordermanagement.entity.LogicalConnection;
import com.airbus.smartdeploy.ordermanagement.exception.CapabilityAlreadyExistsException;
import com.airbus.smartdeploy.ordermanagement.exception.CapabilityNotFoundException;
import com.airbus.smartdeploy.ordermanagement.exception.LogicalConnectionNotFoundException;
import com.airbus.smartdeploy.ordermanagement.service.LogicalConnectionService;
import com.airbus.smartdeploy.ordermanagement.web.dto.mapper.CapabilityDtoMapper;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.Info;
import io.swagger.annotations.SwaggerDefinition;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RefreshScope
@RequestMapping("/api/logicalConnections")
@SwaggerDefinition(info = @Info(description = "Logical Connection Capability Controller", version = "v1.0", title = "SmartDeploy REST operations related to Logical Connection Capabilities"))
public class LogicalConnectionCapabilityController {

    private final LogicalConnectionService logicalConnectionService;

    private final CapabilityDtoMapper capabilityMapper;

    public LogicalConnectionCapabilityController(LogicalConnectionService logicalConnectionService,
                                                 CapabilityDtoMapper capabilityMapper) {
        this.logicalConnectionService = logicalConnectionService;
        this.capabilityMapper = capabilityMapper;
    }

    @GetMapping(value = "{id}/capabilities")
    @ApiOperation(value = "Gets all Capabilities for a Logical Connection", notes = "Gets all Capabilities for a Logical Connection by the given Logical Connection ID.", response = CapabilityDto[].class, produces = "application/json")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successful retrival of Capabilities", response = CapabilityDto[].class),
            @ApiResponse(code = 404, message = "Logical Connection Not Found"),
            @ApiResponse(code = 500, message = "Internal server error")})
    @ApiImplicitParams({
            @ApiImplicitParam(name = TokenAuthenticationService.HEADER_STRING, value = "Authorization token", required = true, dataType = "string", paramType = "header", defaultValue = "Bearer ..."),
            @ApiImplicitParam(name = VersionUtils.PROTOCOL_VERSION_PARAM, value = "API version", required = false, dataType = "string", paramType = "query", defaultValue = "1")})
    public ResponseEntity<List<CapabilityDto>> getLogicalConnectionCapabilities(
            @ApiParam(name = "id", value = "Logical Connection Id", required = true) @PathVariable(value = "id") Long id,
            @RequestParam(value = "page", required = false, defaultValue = "0") int pageNbr,
            @RequestParam(value = "size", required = false, defaultValue = "10") int size)
            throws LogicalConnectionNotFoundException {

        // Get the topology
        LogicalConnection logicConn = logicalConnectionService.getLogicalConnectionById(id);
        if (logicConn == null)
            throw new LogicalConnectionNotFoundException();

        // get the capabilities
        List<Capability> caps = logicalConnectionService.getLogicalConnectionCapabilities(logicConn);

        // Get the page of connections
        Page<Capability> page = new PageImpl<>(caps, new PageRequest(pageNbr, size), caps.size());

        // return
        return new ResponseEntity<>(toDtoList(caps), HttpStatus.OK);
    }

    @GetMapping(value = "{id}/capabilities/{capabilityId}")
    @ApiOperation(value = "Gets a Capability for a Logical Connection", notes = "Gets a Capability for a Logical Connection by the given IDs.", response = CapabilityDto.class, produces = "application/json")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successful retrival of Capability", response = CapabilityDto.class),
            @ApiResponse(code = 404, message = "Capability Not Found"),
            @ApiResponse(code = 500, message = "Internal server error")})
    @ApiImplicitParams({
            @ApiImplicitParam(name = TokenAuthenticationService.HEADER_STRING, value = "Authorization token", required = true, dataType = "string", paramType = "header", defaultValue = "Bearer ..."),
            @ApiImplicitParam(name = VersionUtils.PROTOCOL_VERSION_PARAM, value = "API version", required = false, dataType = "string", paramType = "query", defaultValue = "1")})
    public ResponseEntity<CapabilityDto> getLogicalConnectionCapability(
            @ApiParam(name = "id", value = "Logical Connection Id", required = true) @PathVariable(value = "id") Long id,
            @ApiParam(name = "capabilityId", value = "Capability Id", required = true) @PathVariable(value = "capabilityId") Long capabilityId)
            throws LogicalConnectionNotFoundException, CapabilityNotFoundException {

        // Get the topology
        LogicalConnection logicConn = logicalConnectionService.getLogicalConnectionById(id);
        if (logicConn == null)
            throw new LogicalConnectionNotFoundException();

        // Check the capabilities
        Capability cap = logicalConnectionService.getLogicalConnectionCapability(logicConn, capabilityId);

        // return
        return new ResponseEntity<>(capabilityMapper.toDto(cap), HttpStatus.OK);
    }

    @PostMapping(value = "{id}/capabilities")
    @ApiOperation(value = "Creates a Capability for a Logical Connection", notes = "Creates a Capability for a Logical Connection by the given IDs.", response = CapabilityDto.class, produces = "application/json")
    @ApiResponses(value = {
            @ApiResponse(code = 201, message = "Successful creation of Capability", response = CapabilityDto.class),
            @ApiResponse(code = 400, message = "Capability already exists"),
            @ApiResponse(code = 404, message = "Logical Connection not found"),
            @ApiResponse(code = 500, message = "Internal server error")})
    @ApiImplicitParams({
            @ApiImplicitParam(name = TokenAuthenticationService.HEADER_STRING, value = "Authorization token", required = true, dataType = "string", paramType = "header", defaultValue = "Bearer ..."),
            @ApiImplicitParam(name = VersionUtils.PROTOCOL_VERSION_PARAM, value = "API version", required = false, dataType = "string", paramType = "query", defaultValue = "1")})
    public ResponseEntity<CapabilityDto> createLogicalConnectionCapability(
            @ApiParam(name = "id", value = "Logical Connection Id", required = true) @PathVariable(value = "id") Long id,
            @ApiParam(name = "dto", value = "Capability Details", required = true) @RequestBody CapabilityDto dto)
            throws InvalidRequestException, LogicalConnectionNotFoundException, CapabilityAlreadyExistsException {

        // Check the input
        if (dto == null || StringUtils.isNullOrWhitespace(dto.getName()))
            throw new InvalidRequestException();

        // Get the topology
        LogicalConnection logicConn = logicalConnectionService.getLogicalConnectionById(id);
        if (logicConn == null)
            throw new LogicalConnectionNotFoundException();

        // Update the capability
        Capability cap = logicalConnectionService.createLogicalConnectionCapability(logicConn, dto);

        // return the new entry
        return new ResponseEntity<>(capabilityMapper.toDto(cap), HttpStatus.CREATED);
    }

    @PutMapping(value = "{id}/capabilities/{capabilityId}")
    @ApiOperation(value = "Updates a Capability for a Logical Connection", notes = "Updates a Capability for a Logical Connection by the given IDs.", response = CapabilityDto.class, produces = "application/json")
    @ApiResponses(value = {
            @ApiResponse(code = 201, message = "Successful update of Capability", response = CapabilityDto.class),
            @ApiResponse(code = 400, message = "Capability already exists"),
            @ApiResponse(code = 404, message = "Logical Connection not found"),
            @ApiResponse(code = 500, message = "Internal server error")})
    @ApiImplicitParams({
            @ApiImplicitParam(name = TokenAuthenticationService.HEADER_STRING, value = "Authorization token", required = true, dataType = "string", paramType = "header", defaultValue = "Bearer ..."),
            @ApiImplicitParam(name = VersionUtils.PROTOCOL_VERSION_PARAM, value = "API version", required = false, dataType = "string", paramType = "query", defaultValue = "1")})
    public ResponseEntity<CapabilityDto> updateLogicalConnectionCapability(
            @ApiParam(name = "id", value = "Logical Connection Id", required = true) @PathVariable(value = "id") Long id,
            @ApiParam(name = "capabilityId", value = "Capability Id", required = true) @PathVariable(value = "capabilityId") Long capabilityId,
            @ApiParam(name = "dto", value = "Capability Details", required = true) @RequestBody UpdateCapabilityDto dto)
            throws InvalidRequestException, LogicalConnectionNotFoundException, CapabilityNotFoundException {

        // Check the input
        if (dto == null)
            throw new InvalidRequestException();

        // Get the topology
        LogicalConnection logicConn = logicalConnectionService.getLogicalConnectionById(id);
        if (logicConn == null)
            throw new LogicalConnectionNotFoundException();

        // Get the capability
        Capability cap = logicalConnectionService.getLogicalConnectionCapability(logicConn, capabilityId);

        CapabilityDto dtoC = capabilityMapper.fromUpdateDto(dto);

        // Update the capability
        logicalConnectionService.updateLogicalConnectionCapability(cap, dtoC);

        // return the new entry
        return new ResponseEntity<>(capabilityMapper.toDto(cap), HttpStatus.OK);
    }

    private List<CapabilityDto> toDtoList(List<Capability> list) {

        return list.stream().map(capabilityMapper::toDto).collect(Collectors.toList());
    }

}
