package feature.demo;

//@RunWith(Karate.class)
public class Syr4DemoTest {

}
