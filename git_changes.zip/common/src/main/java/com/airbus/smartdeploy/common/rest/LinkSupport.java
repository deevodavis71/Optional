/**
 *
 */
package com.airbus.smartdeploy.common.rest;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonView;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

/**
 * Container for a link URL.
 *
 * @author humphr_p
 */
@Slf4j
@Data
public class LinkSupport {

    /**
     * Serialising: Container for any extra properties we want to append<br>
     * Deserialising: Any properties which don't match DTO fields will<br>
     * be dumped in here.
     */
    @JsonIgnore
    private Map<String, String> propertiesMap = new HashMap<>();

    @JsonAnySetter
    public void unknownProperty(String name, Object value) {
        propertiesMap.put(name, value != null ? value.toString() : null);
    }

    public void addLink(RelationType rel, String href) {
        propertiesMap.put(rel.getRel(), href);
    }

    @JsonView({View.Template.class, View.Create.class})
    @JsonAnyGetter
    public Map<String, String> getDynamicProperties() {
        return propertiesMap;
    }

    @JsonIgnore
    public String getHref() {
        return propertiesMap.get(RelationType.HREF);
    }

    @JsonIgnore
    public void setHref(String href) {
        propertiesMap.put(RelationType.HREF.getRel(), href);
    }

    /**
     * The last part of a URL for a resource is the
     * resource's id.
     * If the URL does not end with an ID, then we
     * return null.
     *
     * @return the ID or null
     */
    @JsonIgnore
    public Long getId() {
        Long id = null;
        String href = getHref();

        if (href != null) {
            //TODO use UriTemplate
            String[] urlParts = href.split("/");
            if (urlParts.length < 2) {
                log.warn("Malformed URL %s", href);
            } else {
                try {
                    id = Long.parseLong(urlParts[urlParts.length - 1]);
                } catch (NumberFormatException nfe) {
                    // Don't care
                }
            }
        }
        return id;
    }
}
