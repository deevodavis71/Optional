/**
 *
 */
package com.airbus.smartdeploy.common.rest;

/**
 * Json Views.
 * Used to control which fields are serialized
 * when creating JSON from DTOs.
 *
 * @author humphr_p
 */
public class View {
    public interface Template {
    }

    public interface Basic {
    }

    public interface Minimal extends Basic {
    }

    public interface Create {
    }

    public interface Update {
    }

    public interface Read {
    }

}
